#include<iostream>
using namespace std;
int main(){
    cout << "Candy is dandy," << endl << "But liquor is quicker." << endl;

    return 0;
}
